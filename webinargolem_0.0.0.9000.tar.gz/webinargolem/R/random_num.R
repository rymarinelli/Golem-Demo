random_num <- function()
{
  sample(1:5,1)
}
